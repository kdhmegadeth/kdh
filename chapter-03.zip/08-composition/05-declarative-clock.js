// 유틸리티

const oneSecond = () => 1000; // 1초를 밀리초로 변환
const getCurrentTime = () => new Date();
const clear = () => console.clear(); //콘솔 화면 지우기
const log = (message) => console.log(message);

//객체로 변환
const abstractClockTime = (date) => ({
    hours: date.getHours(), //키-벨류 각각
    minutes: date.getMinutes(),
    seconds: date.getSeconds(),
});

// 24시간을 12시간 형식으로 변환
const civilianHours = (clockTime) => ({
  ...clockTime,
  hours: ( clockTime.hours > 12 ) ? clockTime.hours - 12 : clockTime.hours
});

const appendAMPM = () => ({
  ...clockTime,
  ampm: ( clockTime.hours >= 12 ) ? "PM" : "AM",
});

// 고차함수 : 리턴값으로 함수를 사용
// 시간을 받아 target 함수에 전달
const display = target => time => target(time);

const formatClock = format => 
    time => format.replace("hh", time.hours)
                  .replace("mm", time.minutes)
                  .replace("ss", time.seconds)
                  .replace("tt", time.ampm)

// 한자리 숫자 앞에 0 추가
const prependZero = (key) => clockTime =>
  ({
    ...clockTime, 
    [key]: ( clockTime[key] < 10 ) ?  
                  "0" + clockTime[key] : clockTime[key]
  });

const compose = (...fns) => //appendAMPM, civilianHours 순 작동?
  (arg) => fns.reduce(
          (composed, f) => f(composed), 
          arg
        );

// 12시간 형식으로 변환 하고 AM/PM 추가
const convertToCivilianTime = (clockTime) => 
  compose(appendAMPM, civilianHours)(clockTime); //civilianHours, appendAMPM순 작동?
                                    //파라미터

const doubleDigits = civilianTime =>
  compose (
    prependZero("hours"),
    prependZero("minutes"),
    prependZero("seconds")
  )(civilianTime);

const startTicking = () => 
  setInterval(
    compose(
      clear,
      getCurrentTime,
      abstractClockTime,
      doubleDigits,
      formatClock("hh:mm:ss tt"),
      display(log)
    ),
    oneSecond
  );


startTicking();