import {useState, useEffect, useCallback} from 'react';



  const useAnyKeyToRender = () => {
    const [, forceRender] = useState(); //상태 값을 직접 사용하지 않고, 상태를 갱신하는 함수만 사용하는 패턴
                                        //forceRender는 강제로 리렌더링을 유도하는 함수
    useEffect( () => {
      window.addEventListener("keydown", forceRender);
      return () => window.removeEventListener("keydown", forceRender) //컴포넌트가 언마운트될 때 또는 useEffect가 다시 실행되기 직전에 실행됩니다.
    }  ,[] ); //[]니까 한번만 하고 종료?
  };

  
  function WordCount ({ children = "" }) {
    useAnyKeyToRender();
    //useEffect(콜백함수, 의존성배열)
    //useMemo(콜백함수, 의존성배열)
    //useCallback(콜백함수, 의존성배열)

    //해결책: - 함수를 useCallback -> 함수 메모이제이션
    //          불필요한 useEffect 실행을 막을 수 있다. (주소가 달라서 다른 인스턴스로 인식 하는걸 막음)
    const fn = useCallback(() => { //useCallback은 함수를 메모이제이션(memoization)하여 불필요한 렌더링을 방지하는 React Hook
      console.log("hello");        //의존성 배열 [dependencies]의 값이 변경될 때만 함수가 새로 생성
      console.log("hello");        //React에서는 컴포넌트가 리렌더링될 때 내부의 함수도 다시 생성
    }, []);                        //!하지만 useCallback을 사용하면, 의존성 배열이 변경되지 않는 한 기존 함수를 재사용!
  
  
    useEffect( () => {
      console.log("fresh render");
    }, [fn])
  
    return (
      <>
        <p>{children}</p>
      </>
    );
  }

   const UseCallbackEx = () => {
      return(
        <WordCount>You are not going to believe this but...</WordCount>
      )
   }




export default UseCallbackEx;