import React from 'react';
import { useState, useLayoutEffect } from 'react';

function useMousePosition() {
  const [x, setX] = useState(0);
  const [y, setY] = useState(0);

  const setPosition = ({x, y}) => {
    setX(x);
    setY(y); 
  }
  useLayoutEffect(() =>{ //"mousemove" 이벤트는 마우스가 움직일 때마다 해당 시점의 좌표 정보를 포함한 이벤트 객체(MouseEvent)를 반환
    window.addEventListener("mousemove", setPosition);
    return () => window.removeEventListener("mousemove", setPosition)
  }, [])

  return [x, y];
}

const UseLayoutEffectEx = () => {
  const [left, top] = useMousePosition();
  return (                                        //cursor: "none" : 마우스 커서를 숨김, 대신 이 div가 커서처럼 따라다님
    <div style={{ position: "absolute", top, left, cursor: "none" }}>
        {top}x{left}                  
    </div>
  )                                   //top, left는 각각 top: top, left: left를 생략해서 표현
}; 

export default UseLayoutEffectEx;