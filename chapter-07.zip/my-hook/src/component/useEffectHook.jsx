import React from 'react';
import {useState, useEffect} from 'react';

/*
Mount : 화면에 첫 렌더링
Update : 다시 렌더링
Unmount : 화면에서 사라질 때
*/

/*
    1. 상태 변경 : 체크박스 클릭
    2. 가상 Dom에 렌더링 : 이 단계에서 useEffect훅에 전달된 
            콜백 함수 실행
    3. 리얼 Dom 업데이트 : 렌더링 결과 실제 화면에 반영
    alert 창이 나타나는 시점이 리얼DOM 업데이트가 완료되기 전일 수 있음
*/


const UseEffectHook = () => {
  const [checked, setChecked] = useState(false);

  useEffect ( () => {alert(`checked: ${checked.toString()}`)})

  return (
    <div>
      <h2>UseEffect hook</h2>
      <hr />
      <input 
        type="checkbox"
        value={checked}
        onChange={() => setChecked(checked => !checked)} 
      />                       
      {checked ? "checked" : "not checked"}
    </div>
  );// setChecked 함수는 **React의 상태 업데이트 함수(useState에서 제공)**
}; // useState의 두번째 인자인 set 함수는 () 안에 특정 값이 아니라 콜백 함수로 쓸 시
   // 기본적으로 파라미터가 이전 값이다

   //그러므로 !!checked가 아닌 다른 지역변수명으로 해도 상관 없다!!
export default UseEffectHook;