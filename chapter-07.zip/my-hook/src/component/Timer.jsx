import React from 'react';
import {useEffect} from 'react';

const Timer = () => {
  useEffect( () => {                             
    const timer = setInterval( () => { 
      console.log('타이머 돌아가는 중...')
    }, 1000 );

    return () => { //useEffect에서 return은 컴포넌트가 언마운트될 때 실행될 정리(clean-up) 함수
      // Clean Up : 정리 작업 필요
      clearInterval(timer);
      console.log('타이머가 종료되었습니다.');
    }
  }, [] );  //seEffect에서 return으로 전달하는 함수는 즉시 실행되지 않고 특정 시점에만 실행
  
  return (
    <div>
      <span>타이머를 시작합니다. 콘솔을 보세요!</span>   
    </div>
  );
};

export default Timer;