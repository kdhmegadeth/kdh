import {useState, memo} from 'react';

const Cat = ({ name }) => {
  console.log(`rendering ${name}`);
  return  <div>{name}</div>
}

const PureCat = memo(Cat); //캐싱이 된다

const MemoEx = () => {
  const [cats, setCats] = useState(['Biscuit', 'Jungle', 'Outlaw']);


  return (
    <>
      {
        cats.map( (catName, i) => ( 
          <PureCat key={i} name={catName} /> //PureCat 컴퍼넌트 사용
         ) )
      }
      <button onClick={ () => setCats([...cats, prompt('Name a cat')]) }>
        Add a Cat
      </button>
    </>
  );
};

export default MemoEx;