import { useState } from "react";
import { useReducer } from "react";
             //!! 밑에꺼 확인해 보기
const firstUser = {
  id: '0391-3233-3201',
  firstName: "Bill",
  lastName: "Wilson",
  city: "Missoula",
  state: "Montana",
  email: "billwilson@mtnwilsons.com",
  admin: false
}


function userReducer(user, newDetails) {
  // 전개 연산자 (스프레드 연산자) 를 사용하여
  // 기존 상태를 복사하고 새로운 속성을 추가하거나 수정가능
  return { ...user, ...newDetails  }
}


function User() {                 //이름이 useReducer로 바뀌어도 reducer
  const [user, setUser] = useReducer(userReducer, firstUser);
               //useReducer이면 setUser여도 dispatch다
  return (
    <div>
      <h1>{user.firstName}{user.lastName} - {user.admin ? 'Admin' : 'User'}</h1>
      <p>Email: {user.email}</p>
      <p>
        Location: {user.city}, {user.state}
      </p>
      <button
        onClick={ () => setUser( { admin: true } ) }
      >Make Admin</button>
    </div>
  )


}


const UseReducerEx = () => {     

  return (               
    <User />
  );
};

export default UseReducerEx;