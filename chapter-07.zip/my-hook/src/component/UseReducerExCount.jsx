import { useReducer } from "react";
             //!! 밑에꺼 확인해 보기  
             //그리고 useReducerExCount로 바꾸기
// reducer - state를 업데이트하는 역할
function reducer(state, action) {
  switch (action.type) {
    case 'INCREMENT': 
      return { count: state.count + 1 };
    case 'DECREASE': 
      return { count: state.count - 1 };
    default:
      return state; // default 추가
  }
}

const UseReducerEx = () => {     
  // [state, dispatch] = useReducer(reducer, 초기값)
  const [state, dispatch] = useReducer(reducer, { count: 0 });

  return (                         
    <div>
      <p>Count: {state.count}</p>
      <button onClick={() => dispatch({ type: 'INCREMENT' })}>1증가</button>
      <button onClick={() => dispatch({ type: 'DECREASE' })}>1감소</button>
    </div>
  );
};

export default UseReducerEx;

/*
// reducer  - state를 업데이트 하는 역할 (은행)
// dispatch - state 업데이트를 위한 요구를 하는 주체
// action   - 요구의 내용 

function reducer(state, action) {
  switch (action.type) {
    case 'INCREMENT': 
      return { count: state.count + 1 };
    case 'DECREASE': 
      return { count: state.count - 1 };
    default:
      return state
  }
}

const UseReducerEx = () => {     
  //[상태변수, 요청하는 주체] = useReducer(상태변경함수, 초기값)     
  const [state, dispatch] = useReducer(reducer, {count: 0})//count : state 초기값
                                   //짧은건 reducer 자리에 () => reducer(state, action) 이렇게 할 수도 있다 
  return (                         //reducer가 dispatch로부터 받아서 작업한 뒤 값을 state로 보낸다
    <div>
      <p>Count: {state.count}</p>
      <button onClick={ () => dispatch({type: 'INGREMENT'})}>1증가</button>
      <button onClick={ () => dispatch({type: 'DECREMENT'})}>1감소</button>
    </div>
  );
};

export default UseReducerEx;
*/