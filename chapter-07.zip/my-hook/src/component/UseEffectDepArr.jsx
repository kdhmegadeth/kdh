import React from 'react';
import { useState, useEffect } from 'react';
/*
  1. useEffect( () => {} ) // 렌더링 될 때 마다 실행
  2. useEffect( () => {}, [value] ) //value값이 바뀔 때 실행
  3. useEffect( () => {}, [] ) // 렌더링 될 때 딱 한번만 실행
  4. useEffect( () => {
        // 부수 작업
      
        return () => {
           // 언마운트 될 때 Clean-up 함수
        }

    })
*/

const UseEffectDepArr = () => {
  const [val, set] = useState("") //현재 문장 쓰는 상태
  const [phrase, setPhrase] = useState("좋아하는 문장을 쓰세요...") //쓴 문장이 전송 된 상태

  const handleCreatePhrase = () => {
    setPhrase(val); //완성되면 문장 전달
    set(""); //완성되면 리셋
  };

  useEffect( () => {
    console.log(`input box typing "${val}`) // 완성되면 리셋
  }, [val]);

  useEffect( () => {
    console.log(`saved phrase: "${phrase}"`)
  }, [phrase]);


  return (
  <> 
    <label htmlFor="">좋아하는 문장:</label>
    <input 
        type="text" 
        value={val} 
        placeholder={phrase}  //e.target.value는 진짜 DOM"요소"에 저장 되어 있는 값을 가져 오는 것
        onChange={ e => set(e.target.value)} //이게 없으면 입력 자체가 화면에 안 뜸 //왜냐면 가상 DOM을 통하기 때문에
    />                                       
    <button onClick={handleCreatePhrase}>send</button>
  </>
  )
}

export default UseEffectDepArr;