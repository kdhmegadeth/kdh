import React from 'react';
import { useState } from 'react';
import Timer from './Timer';

const UseEffectCleanUp = () => {
  const [showTimer, setShowTimer] = useState(false)
        //불린값      
        //false가 호출될 때 timer가 멈춘다
  return ( 
    <div>
      {showTimer && <Timer />} 
      <button onClick={ () => setShowTimer(!showTimer)} >Toggle Timer</button>
    </div>
  )
} //{showTimer && <Timer />}  쇼트 서킷 : && 연산자는 왼쪽 값이 true일 때만 오른쪽 값을 평가합니다.

export default UseEffectCleanUp;