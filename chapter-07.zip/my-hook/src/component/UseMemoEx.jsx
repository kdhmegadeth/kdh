import React, { useEffect, useState, useMemo } from 'react';

const useAnyKeyToRender = () => {
  const [, forceRender] = useState();

  useEffect( () => {
    window.addEventListener("keydown", forceRender);
    return () => window.removeEventListener("keydown", forceRender)
  }  ,[] ); //[]니까 한번만 하고 종료?
};

function WordCount ({ children = "" }) {
  useAnyKeyToRender();

  //const words = "gnar";                   1.useMemo는 첫 번째 인자로 "함수"를 받음 2.두 번째 인자로 의존성 배열을 받음 → [dependency1, dependency2, ...]
  // 이슈                                   3. 의존성이 변경될 때만 첫 번째 인자로 전달된 함수가 실행됨.  4.변경이 없으면 이전 값을 그대로 재사용.
  //const words = ["sick", "powder", "day"]; //배열, 객체, 함수는 키다운 할 때 마다 새로운 주소의 인스턴스 생성
  //해결책 : useMemo(콜, 의);
  const words = useMemo( () => children.split(" "), [children]); //문자열 '배열': 인스턴스 주소
  //console.log("랜더링...")                                     //useMemo는 불필요한 메모리 할당을 방지하고 같은 데이터(배열)를 계속 재사용하도록 최적화하
                                                                 /*
                                                                  useMemo가 하는 일
                                                                  1.children.split(" ")을 실행하여 문자열을 배열로 변환.
                                                                  2.useMemo가 배열(words)을 메모이제이션(저장)하여 재사용.
                                                                  3.children이 변경되지 않는 한, 새로운 배열을 만들지 않음.
                                                                  → 즉, 컴포넌트가 리렌더링되더라도 words의 메모리 주소가 유지됨.
                                                                 */ 

  useEffect( () => {
    console.log("fresh render");
  }, [words])

  return (
    <>
      <p>{children}</p>
      <p><strong>{words.length} - words</strong></p>
    </>
  );
}

// <UseMemoEx>You are not going to beleive this but...</UseMemoEx>
export default function UseMemoEx () { //children prop은 자동으로 만들어짐?
  return <WordCount>You are not going to beleive this but...</WordCount>
};



