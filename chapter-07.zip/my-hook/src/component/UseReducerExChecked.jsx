import { useState } from "react";
import { useReducer } from "react";
             //UseReducerExChecked App 추가하고 이름 바꾸는거

// reducer - state를 업데이트하는 역할

function reducer (state, action) {
  if(action.type ==='TOGGLE') {
    return !state;
  }
  return state;
}

const UseReducerEx = () => {     
//  const [checked, setChecked] = useState(false)
  const [checked, dispatch] = useReducer(reducer, false)
  return (       //setChecked 대신              
    <div>
      <input 
        type="checkbox" 
        value={checked} 
        onChange={() => dispatch( {type: 'TOGGLE'} )}
      />
      {checked ? 'checked' : 'notchecked'}
    </div>
  );
};

export default UseReducerEx;