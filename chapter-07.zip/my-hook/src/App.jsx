import { Routes, Route, Link } from "react-router-dom";

import UseEffectHook from "./component/useEffectHook";
import UseEffectDepArr from "./component/UseEffectDepArr";
import UseEffectCleanUp from "./component/UseEffectCleanUp";
import UseMemoEx from "./component/UseMemoEx";
import UseCallbackEx from "./component/UseCallbackEx";
import UseLayoutEffectEx from "./component/UseLayoutEffectEx";
import EasyUseReducer from "./component/EasyUseReducer";
import UseReducerEx from "./component/UseReducerEx";
import MemoEx from "./component/MemoEx";
import DataFetcher from "./exercise/DataFetcher"

function App() {
                         //새로 만드는 방법 rsc
               
  return (
    <div className="App">
      <nav>
        <Link to="/">useEffect</Link>
        <Link to="/deparr"> |의존성 배열</Link>
        <Link to="/cleanup"> | 클린업</Link>
        <Link to="/usememo"> | UseMemo</Link>
        <Link to="/usecallback"> | UseCallbackEx</Link>
        <Link to="/uselayouteffect"> | UseLayoutEffectEx</Link>
        <Link to="/easyusereducer"> | EasyUseReducer</Link>
        <Link to="/usereducer"> | UseReducerEx</Link>
        <Link to="/memoex"> | MemoEx</Link>
        <Link to="/datafetcher"> | DataFetcher</Link>
      </nav>
      <Routes>
        <Route path="/" element={<UseEffectHook/>}></Route>
        <Route path="/deparr" element={<UseEffectDepArr/>}></Route>
        <Route path="/cleanup" element={<UseEffectCleanUp/>}></Route>
        <Route path="/usememo" element={<UseMemoEx />}></Route>
        <Route path="/usecallback" element={<UseCallbackEx />}></Route>
        <Route path="/uselayouteffect" element={<UseLayoutEffectEx />}></Route>
        <Route path="/easyusereducer" element={<EasyUseReducer />}></Route>
        <Route path="/usereducer" element={<UseReducerEx />}></Route>
        <Route path="/memoex" element={<MemoEx />}></Route>
        <Route path="/datafetcher" element={<DataFetcher url="https://jsonplaceholder.typicode.com/users" />}></Route>
      </Routes>
    </div>
  )
}

export default App
