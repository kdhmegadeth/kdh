import React from 'react';
import { useState, useEffect, useMemo } from 'react';


const DataFetcher = ({ url }) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
                      //url 종속변수가 있을 시 부수효과 발생, 그 외 에는 통과
  useEffect ( () => {
    const fetchData = async () => {
      try {
        const response = await fetch(url);
        if(!response.ok) {
          throw new Error('API 호출 실패');
        }
        const result = await response.json();
        setData(result);
      } catch (err){
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [url])

  const cachedData = useMemo( () => data, [data] ); //데이터가 새로 갱신 되지 않는 이상 패스
  if (loading) return <div>Loading........ </div> //loading이 true면 fetchData를 실행하고(?), Loading true 상태가 바뀌면 Loding이 없어지게 된다
  if (error) return <div>Error: {error}</div> //error가 truthy 해서 작동하게 되면

  return (
    <div>
      {cachedData && 
        cachedData.map( (item) => <div key={item.id}>{item.name}</div>)
      }
    </div>
  );
};

export default DataFetcher;

//<DataFetcher url="https://jsonplaceholder.typicode.com/users" />